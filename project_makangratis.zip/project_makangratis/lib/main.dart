import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Untuk autentikasi
import 'package:project_makangratis/firebase_options.dart';
import 'package:project_makangratis/ui/add.dart';
import 'package:project_makangratis/ui/detail.dart';
import 'package:project_makangratis/ui/edit.dart';
import 'package:project_makangratis/ui/payment.dart';
import 'package:project_makangratis/ui/register.dart';
import 'ui/login.dart';
import 'ui/home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      initialRoute: '/login',
      routes: {
        '/register': (context) => const RegisterPage(),
        '/login': (context) => const LoginPage(),
        '/home': (context) => const HomePage(),
        '/add': (context) => const AddPage(),
        '/detail': (context) {
          final args = ModalRoute.of(context)?.settings.arguments
              as Map<String, dynamic>?; // Mengambil argumen
          if (args != null) {
            return EventDetailPage(
              event: args['event'],
              currentUserEmail: args['currentUserEmail'],
            );
          }
          return const Scaffold(
            body: Center(child: Text('Invalid arguments passed to /detail')),
          );
        },
        '/payment': (context) => const PaymentPage(),
        '/edit': (context) {
          final args = ModalRoute.of(context)?.settings.arguments
              as Map<String, dynamic>?;
          if (args != null && args.containsKey('eventName')) {
            return EditPage(eventName: args['eventName']);
          }
          return const Scaffold(
            body: Center(child: Text('Invalid arguments passed to /edit')),
          );
        },
      },
    );
  }
}
