// // ignore_for_file: file_names, prefer_const_constructors, unnecessary_new, prefer_collection_literals, unused_field, library_private_types_in_public_api, no_logic_in_create_state, prefer_const_constructors_in_immutables, import_of_legacy_library_into_null_safe, use_build_context_synchronously, unnecessary_null_comparison, use_key_in_widget_constructors, deprecated_member_use, prefer_final_fields, prefer_interpolation_to_compose_strings, avoid_print, unused_local_variable, unused_import, empty_constructor_bodies

// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'dart:async';
// import 'package:url_launcher/url_launcher.dart';
// import 'package:webview_flutter/webview_flutter.dart';
// import 'package:http/http.dart' as http;
// import '../../session.dart' as sessionvar;

// class ShowHtmlPage extends StatefulWidget {
//   @override
//   _TopUp2State createState() => _TopUp2State(url);

//   final String url;

//   ShowHtmlPage({Key? key, required this.url}) : super(key: key);
// }

// class _TopUp2State extends State<ShowHtmlPage> {
//   String url;
//   Completer<WebViewController> _controller = Completer<WebViewController>();
//   final Set<String> _favorites = Set<String>();

//   _TopUp2State(this.url) {}

//   Future<String> backscreen() async {
//     Map paramData = {
//       'jenis': "Top Up",
//       'username': sessionvar.userLogin.user_username,
//       'nilai': sessionvar.bayaritem['nilai'],
//       'bank': "", 
//       'pembayaran_id': sessionvar.bayaritem['htrans_id'],
//       'rek': "", 
//       'atas_nama': ""
//     };
//     http
//         .post(Uri.parse(sessionvar.ipaddress + "/api/users/transsaldo/insert"),
//             headers: {}, body: paramData)
//         .then((res) {
//           print(res.body); 
//       Navigator.pop(context);
//     }).catchError((err) {
//       print(err);
//     });
//     return "";
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: new AppBar(
//         title: new Text("Pembayaran Dengan Midtrans"),
//         actions: <Widget>[
//           IconButton(
//             icon: Icon(Icons.map),
//             onPressed: backscreen,
//           ),
//         ],
//       ),
//       body: WebView(
//         initialUrl: url,
//         javascriptMode: JavaScriptMode.unrestricted,
//         // withZoom: false,
//       ),
//       /*
//       body: WebView(
//         //initialUrl: url,
//         initialUrl: "http://www.youtube.com",
//         onWebViewCreated: (WebViewController webViewController) {
//           _controller.complete(webViewController);
//         },
//       ),
//       */
//     );
//   }
// }

// class Menu extends StatelessWidget {
//   Menu(this._webViewControllerFuture, this.favoritesAccessor);
//   final Future<WebViewController> _webViewControllerFuture;
//   // ignore: todo
//   // TODO(efortuna): Come up with a more elegant solution for an accessor to this than a callback.
//   final Function favoritesAccessor;

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder(
//       future: _webViewControllerFuture,
//       builder:
//           (BuildContext context, AsyncSnapshot<WebViewController> controller) {
//         if (!controller.hasData) return Container();
//         return PopupMenuButton<String>(
//           onSelected: (String value) async {
//             if (value == 'Email link') {
//               var url = await controller.data!.currentUrl();
//               await launch(
//                   'mailto:?subject=Check out this cool Wikipedia page&body=$url');
//             } else {
//               var newUrl = await Navigator.push(context,
//                   MaterialPageRoute(builder: (BuildContext context) {
//                 return FavoritesPage(favoritesAccessor());
//               }));
//               ScaffoldMessenger.of(context).removeCurrentSnackBar();
//               if (newUrl != null) controller.data!.loadUrl(newUrl);
//             }
//           },
//           itemBuilder: (BuildContext context) => <PopupMenuItem<String>>[
//             const PopupMenuItem<String>(
//               value: 'Email link',
//               child: Text('Email link'),
//             ),
//             const PopupMenuItem<String>(
//               value: 'See Favorites',
//               child: Text('See Favorites'),
//             ),
//           ],
//         );
//       },
//     );
//   }
// }

// class FavoritesPage extends StatelessWidget {
//   FavoritesPage(this.favorites);
//   final Set<String> favorites;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Favorite pages')),
//       body: ListView(
//           children: favorites
//               .map((url) => ListTile(
//                   title: Text(url), onTap: () => Navigator.pop(context, url)))
//               .toList()),
//     );
//   }
// }

// class NavigationControls extends StatelessWidget {
//   const NavigationControls(this._webViewControllerFuture)
//       : assert(_webViewControllerFuture != null);

//   final Future<WebViewController> _webViewControllerFuture;

//   @override
//   Widget build(BuildContext context) {
//     return FutureBuilder<WebViewController>(
//       future: _webViewControllerFuture,
//       builder:
//           (BuildContext context, AsyncSnapshot<WebViewController> snapshot) {
//         final bool webViewReady =
//             snapshot.connectionState == ConnectionState.done;
//         final WebViewController? controller = snapshot.data;
//         return Row(
//           children: <Widget>[
//             IconButton(
//               icon: const Icon(Icons.arrow_back_ios),
//               onPressed: !webViewReady
//                   ? null
//                   : () => navigate(context, controller!, goBack: true),
//             ),
//             IconButton(
//               icon: const Icon(Icons.arrow_forward_ios),
//               onPressed: !webViewReady
//                   ? null
//                   : () => navigate(context, controller!, goBack: false),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   navigate(BuildContext context, WebViewController controller,
//       {bool goBack = false}) async {
//     bool canNavigate =
//         goBack ? await controller.canGoBack() : await controller.canGoForward();
//     if (canNavigate) {
//       goBack ? controller.goBack() : controller.goForward();
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//             content: Text("No ${goBack ? 'back' : 'forward'} history item")),
//       );
//     }
//   }
// }
