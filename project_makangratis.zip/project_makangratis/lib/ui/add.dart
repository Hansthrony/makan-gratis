import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddPage extends StatefulWidget {
  const AddPage({super.key});

  @override
  State<AddPage> createState() => _AddPageState();
}

class _AddPageState extends State<AddPage> {
  final _formKey = GlobalKey<FormState>();
  final _eventNameController = TextEditingController();
  final _eventPurposeController = TextEditingController();
  final _eventDescriptionController = TextEditingController();
  final _donationAmountController = TextEditingController();
  final _locationController = TextEditingController();

  LatLng? _selectedLocation =
      LatLng(-7.2915433021352385, 112.75875509294768); // Default lokasi

  Future<void> _addEventToDatabase() async {
    final eventName = _eventNameController.text;
    final eventPurpose = _eventPurposeController.text;
    final eventDescription = _eventDescriptionController.text;
    final donationAmount = double.parse(_donationAmountController.text);
    final locationName = _locationController.text;
    final latitude = _selectedLocation?.latitude;
    final longitude = _selectedLocation?.longitude;

    // Ambil pengguna yang sedang login
    final currentUser = FirebaseAuth.instance.currentUser;
    final createdBy =
        currentUser?.email ?? 'Unknown User'; // Gunakan email pengguna

    try {
      await FirebaseFirestore.instance.collection('events').add({
        'eventName': eventName,
        'eventPurpose': eventPurpose,
        'eventDescription': eventDescription,
        'donationAmount': donationAmount,
        'donationCollected': 0.0, // Donasi terkumpul awalnya 0
        'locationName': locationName,
        'latitude': latitude,
        'longitude': longitude,
        'createdBy': createdBy,
        'createdAt': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Acara berhasil ditambahkan')),
      );

      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menambahkan acara: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8EDE3),
      appBar: AppBar(
        title: const Text('Tambah Acara'),
        backgroundColor: const Color(0xFFD0B8A8),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const SizedBox(height: 5),
              TextFormField(
                controller: _eventNameController,
                decoration: const InputDecoration(
                  labelText: 'Nama Acara',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _eventPurposeController,
                decoration: const InputDecoration(
                  labelText: 'Tujuan Acara',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Tujuan acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _eventDescriptionController,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi Acara',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Deskripsi acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _donationAmountController,
                decoration: const InputDecoration(
                  labelText: 'Jumlah Donasi yang Dibutuhkan',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Jumlah donasi tidak boleh kosong';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Masukkan jumlah donasi yang valid';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                  labelText: 'Lokasi Pembagian Makanan',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Lokasi tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              Container(
                height: 280,
                child: FlutterMap(
                  options: MapOptions(
                    center: _selectedLocation,
                    zoom: 17.0,
                    onTap: (tapPosition, point) {
                      setState(() {
                        _selectedLocation = point;
                      });
                    },
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                      subdomains: ['a', 'b', 'c'],
                    ),
                    if (_selectedLocation != null)
                      MarkerLayer(
                        markers: [
                          Marker(
                            point: _selectedLocation!,
                            builder: (ctx) => const Icon(
                              Icons.location_pin,
                              color: Colors.red,
                              size: 40,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC5705D),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _addEventToDatabase();
                  }
                },
                child: const Text(
                  'TAMBAH ACARA',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
