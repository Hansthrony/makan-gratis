// ignore_for_file: use_super_parameters, prefer_const_constructors

import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:project_makangratis/ShowHtmlPage.dart';
import 'package:xendit/xendit.dart';

class PaymentPage extends StatelessWidget {
  const PaymentPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Controllers for form inputs
    TextEditingController txtnama = TextEditingController();
    TextEditingController txtemail = TextEditingController();
    TextEditingController txtnominal = TextEditingController();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    final eventNames = args?['eventName'] ?? 'Unknown Event';

    // Function to update donation in Firestore
    Future<void> callbackLoad(String eventName, int donationAmount) async {
      try {
        FirebaseFirestore firestore = FirebaseFirestore.instance;

        // Query Firestore to find the document by event name
        var querySnapshot = await firestore
            .collection('events')
            .where('eventName', isEqualTo: eventName.trim())
            .limit(1)
            .get();
        print("Searching for event: ${eventName.trim().toLowerCase()}");

        if (querySnapshot.docs.isNotEmpty) {
          String documentId = querySnapshot.docs.first.id;

          // Update the donationCollected field
          await firestore.collection('events').doc(documentId).update({
            'donationCollected': FieldValue.increment(donationAmount),
            'updatedAt': Timestamp.now(),
          });

          print("Donation updated successfully!");
        } else {
          print("Event not found.");
        }
      } catch (e) {
        print("Error updating donation: $e");
      }

      Navigator.of(context).pop();
    }

    // Function to process payment via Xendit
    void bayar(String paymentNumber, String nominal) async {
      try {
        Xendit xendit = Xendit(
          apiKey:
              "xnd_development_dJclgNvUP6u2u54ZfAtt0MqFzp6JEd0792G6S7AfOpyHzD3bryGFJzgnLsBvduIe",
        );

        var res = await xendit.invoke(
          endpoint: "POST https://api.xendit.co/v2/invoices",
          headers: {
            // Additional headers can be added here
          },
          parameters: {
            "external_id": paymentNumber,
            "amount": nominal,
          },
          queryParameters: {
            // Optional query parameters can be added here
          },
        );

        print("Payment Number: $paymentNumber");
        print("Nominal: $nominal");
        var url = res['invoice_url'];
        print("Invoice URL: $url");

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ShowHtmlPage(url: url),
          ),
        ).then((value) {
          int donationAmount = int.parse(txtnominal.text);
          String eventName = eventNames;
          print("Searching for event: $eventName");
          callbackLoad(eventName, donationAmount);
        });
      } catch (e) {
        print("Payment error: $e");
      }
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8EDE3),
      appBar: AppBar(
        backgroundColor: const Color(0xFFD0B8A8),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'Donasi',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: txtnama,
              decoration: const InputDecoration(
                labelText: "Nama Yang Berdonasi",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: txtemail,
              decoration: const InputDecoration(
                labelText: "Email Yang Berdonasi",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: txtnominal,
              decoration: const InputDecoration(
                labelText: "Jumlah Donasi",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            const Spacer(),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (txtnama.text.isEmpty ||
                      txtemail.text.isEmpty ||
                      txtnominal.text.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Mohon isi semua field')),
                    );
                    return;
                  }

                  var rng = Random();
                  bayar(rng.nextInt(1000000).toString(), txtnominal.text);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC5705D),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  "Donasi",
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
