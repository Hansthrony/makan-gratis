import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EditPage extends StatefulWidget {
  final String eventName;

  const EditPage({
    super.key,
    required this.eventName,
  });

  @override
  State<EditPage> createState() => _EditPageState();
}

class _EditPageState extends State<EditPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _eventNameController;
  late TextEditingController _eventPurposeController;
  late TextEditingController _eventDescriptionController;
  late TextEditingController _donationAmountController;
  late TextEditingController _locationController;

  LatLng? _selectedLocation;

  @override
  void initState() {
    super.initState();
    _eventNameController = TextEditingController();
    _eventPurposeController = TextEditingController();
    _eventDescriptionController = TextEditingController();
    _donationAmountController = TextEditingController();
    _locationController = TextEditingController();

    _fetchEventData();
  }

  Future<void> _fetchEventData() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('events')
        .where('eventName', isEqualTo: widget.eventName)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final doc = querySnapshot.docs.first;
      final data = doc.data();
      setState(() {
        _eventNameController.text = data['eventName'] ?? '';
        _eventPurposeController.text = data['eventPurpose'] ?? '';
        _eventDescriptionController.text = data['eventDescription'] ?? '';
        _donationAmountController.text = data['donationAmount'].toString();
        _locationController.text = data['locationName'] ?? '';
        _selectedLocation = LatLng(data['latitude'], data['longitude']);
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data acara tidak ditemukan')),
      );
      Navigator.pop(context);
    }
  }

  Future<void> _updateEventInDatabase() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('events')
        .where('eventName', isEqualTo: widget.eventName)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      final docId = querySnapshot.docs.first.id; // Ambil ID dokumen
      final eventName = _eventNameController.text;
      final eventPurpose = _eventPurposeController.text;
      final eventDescription = _eventDescriptionController.text;
      final donationAmount = double.parse(_donationAmountController.text);
      final locationName = _locationController.text;
      final latitude = _selectedLocation?.latitude;
      final longitude = _selectedLocation?.longitude;

      try {
        await FirebaseFirestore.instance
            .collection('events')
            .doc(docId)
            .update({
          'eventName': eventName,
          'eventPurpose': eventPurpose,
          'eventDescription': eventDescription,
          'donationAmount': donationAmount,
          'locationName': locationName,
          'latitude': latitude,
          'longitude': longitude,
          'updatedAt': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Acara berhasil diperbarui')),
        );

        Navigator.pop(context, true);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memperbarui acara: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Gagal menemukan acara untuk diperbarui')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8EDE3),
      appBar: AppBar(
        title: const Text('Edit Acara'),
        backgroundColor: const Color(0xFFD0B8A8),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const SizedBox(height: 5),
              TextFormField(
                controller: _eventNameController,
                decoration: const InputDecoration(
                  labelText: 'Nama Acara',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _eventPurposeController,
                decoration: const InputDecoration(
                  labelText: 'Tujuan Acara',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Tujuan acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _eventDescriptionController,
                decoration: const InputDecoration(
                  labelText: 'Deskripsi Acara',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Deskripsi acara tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _donationAmountController,
                decoration: const InputDecoration(
                  labelText: 'Jumlah Donasi yang Dibutuhkan',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Jumlah donasi tidak boleh kosong';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Masukkan jumlah donasi yang valid';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                  labelText: 'Lokasi Pembagian Makanan',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Lokasi tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              Container(
                height: 280,
                child: FlutterMap(
                  options: MapOptions(
                    center:
                        _selectedLocation ?? LatLng(-7.2915433, 112.7587550),
                    zoom: 17.0,
                    onTap: (tapPosition, point) {
                      setState(() {
                        _selectedLocation = point;
                      });
                    },
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                      subdomains: ['a', 'b', 'c'],
                    ),
                    if (_selectedLocation != null)
                      MarkerLayer(
                        markers: [
                          Marker(
                            point: _selectedLocation!,
                            builder: (ctx) => const Icon(
                              Icons.location_pin,
                              color: Colors.red,
                              size: 40,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC5705D),
                ),
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _updateEventInDatabase();
                  }
                },
                child: const Text(
                  'PERBARUI ACARA',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
