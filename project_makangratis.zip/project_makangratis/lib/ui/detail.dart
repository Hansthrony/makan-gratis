// ignore_for_file: library_private_types_in_public_api, unused_field

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:project_makangratis/ui/edit.dart';
import 'package:project_makangratis/ui/payment.dart';

class EventDetailPage extends StatefulWidget {
  final Map<String, dynamic> event;
  final String currentUserEmail;

  const EventDetailPage({
    super.key,
    required this.event,
    required this.currentUserEmail,
  });

  @override
  _EventDetailPageState createState() => _EventDetailPageState();
}

class _EventDetailPageState extends State<EventDetailPage> {
  late Map<String, dynamic> eventDetails;
  final ImagePicker picker = ImagePicker();
  XFile? _selectedImage; // Variabel untuk menyimpan gambar yang dipilih

  @override
  void initState() {
    super.initState();
    eventDetails = widget.event;
  }

  Future<void> _fetchEventData() async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('events')
        .where('eventName', isEqualTo: widget.event['eventName'])
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      setState(() {
        eventDetails = querySnapshot.docs.first.data();
      });
    }
  }

  void _navigateToEditPage() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditPage(eventName: eventDetails['eventName']),
      ),
    );

    if (result == true) {
      _fetchEventData(); // Refresh data if edit was successful
    }
  }

  void _deleteEvent() async {
    final confirmation = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Konfirmasi"),
        content: const Text("Apakah Anda yakin ingin menghapus acara ini?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false), // Tidak
            child: const Text("Batal"),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true), // Ya
            child: const Text("Hapus"),
          ),
        ],
      ),
    );

    if (confirmation == true) {
      try {
        await FirebaseFirestore.instance
            .collection('events')
            .where('eventName', isEqualTo: eventDetails['eventName'])
            .get()
            .then((querySnapshot) {
          for (var doc in querySnapshot.docs) {
            doc.reference.delete(); // Hapus dokumen
          }
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Acara berhasil dihapus")),
        );

        Navigator.of(context).pop();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Gagal menghapus acara: $e")),
        );
      }
    }
  }

  Future getImageFromGallery() async {
    var image = await picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = image;
    });

    // simpan ke firebase storage
  }

  Future getImageFromCamera() async {
    var image = await picker.pickImage(source: ImageSource.camera);
    setState(() {
      _selectedImage = image;
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();

    // Tampilkan popup pilihan untuk mengambil gambar dari galeri atau kamera
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text("Pilih dari Galeri"),
              onTap: () async {
                getImageFromGallery();
                Navigator.pop(context); // Tutup modal
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text("Gunakan Kamera"),
              onTap: () async {
                getImageFromCamera();
                Navigator.pop(context); // Tutup modal
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final eventName = eventDetails['eventName'] ?? 'Unknown Event';
    final eventPurpose = eventDetails['eventPurpose'] ?? 'Unknown Purpose';
    final location = eventDetails['locationName'] ?? 'Unknown Location';
    final donationAmount = eventDetails['donationAmount'] ?? 0.0;
    final donationCollected = eventDetails['donationCollected'] ?? 0.0;
    final description =
        eventDetails['eventDescription'] ?? 'No description available';
    final latitude = eventDetails['latitude'] ?? 0.0;
    final longitude = eventDetails['longitude'] ?? 0.0;
    final createdBy = eventDetails['createdBy'] ?? '';

    final formattedDonation = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp. ',
      decimalDigits: 0,
    ).format(donationAmount);

    final formattedCollected = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp. ',
      decimalDigits: 0,
    ).format(donationCollected);

    final progress = (donationCollected / donationAmount).clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: const Color(0xFFF8EDE3),
      appBar: AppBar(
        title: const Text('Detail Acara'),
        backgroundColor: const Color(0xFFD0B8A8),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              eventName,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Tujuan Acara: $eventPurpose',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 16),
            Text(
              'Deskripsi Acara:',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              description,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 16),
            Text(
              'Donasi Terkumpul: $formattedCollected / $formattedDonation',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.grey[300],
              color: const Color(0xFFC5705D),
              minHeight: 10.0,
            ),
            const SizedBox(height: 16),
            Text(
              'Peta Lokasi: ',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              '$location',
              style: const TextStyle(
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 300,
              child: FlutterMap(
                options: MapOptions(
                  center: LatLng(latitude, longitude),
                  zoom: 17.0,
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                    subdomains: ['a', 'b', 'c'],
                  ),
                  MarkerLayer(
                    markers: [
                      Marker(
                        point: LatLng(latitude, longitude),
                        builder: (ctx) => const Icon(
                          Icons.location_pin,
                          color: Colors.red,
                          size: 40,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(
                          context,
                          '/payment',
                          arguments: {'eventName': eventDetails['eventName']},
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFC5705D),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text("Donasi"),
                    ),
                    ElevatedButton(
                      onPressed: _pickImage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFC5705D),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 40, vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text("Upload Gambar"),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (_selectedImage != null)
                  Column(
                    children: [
                      const Text(
                        "Gambar yang Dipilih:",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Image.file(
                        File(_selectedImage!.path),
                        width: 200,
                        height: 200,
                        fit: BoxFit.cover,
                      ),
                    ],
                  ),
                const SizedBox(height: 16),
                if (createdBy == widget.currentUserEmail) ...[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: _navigateToEditPage,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFC5705D),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 40, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("Edit Acara"),
                      ),
                      ElevatedButton(
                        onPressed: _deleteEvent,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFC5705D),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 40, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("Hapus Acara"),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
