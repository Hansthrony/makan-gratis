package com.example.project_makangratis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
